import yaml
import os
import sys
import re as re

import multiprocessing
import numpy as np
from gensim.models.word2vec import Word2Vec
from gensim.corpora.dictionary import Dictionary
import random as rn
seed_value= 128  
os.environ['PYTHONHASHSEED']=str(seed_value)
np.random.seed(seed_value)  
rn.seed(seed_value)
import pandas as pd
import sys
import csv
from sklearn.model_selection import train_test_split
from sklearn.model_selection import StratifiedKFold 
from sklearn.metrics import f1_score, precision_score, recall_score, roc_auc_score, balanced_accuracy_score, accuracy_score
from sklearn.utils import resample
import matplotlib.pyplot as plt

import tensorflow as tf
from tensorflow.python.client import device_lib


import Metrics
from keras import backend as K
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Dropout, Embedding, LSTM, Bidirectional, Activation, LeakyReLU
from keras.models import model_from_yaml
import kerastuner as kt
from kerastuner import HyperModel





#config = tf.ConfigProto( device_count = {'GPU': 1 , 'CPU': 16} ) 
#sess = tf.Session(config=config) 
#K.set_session(sess)
print("Num GPUs Available: ", len(tf.config.experimental.list_physical_devices('GPU')))



csv.field_size_limit(100000000)
sys.setrecursionlimit(1000000)
# set parameters:
vocab_dim = 100
maxlen = 100 
n_iterations = 1  # ideally more..
n_exposures = 10
window_size = 7
batch_size = 24
n_epoch = 3
input_length = 100
cpu_count = multiprocessing.cpu_count()

test_list = []
neg_full = []
pos_full = []
syntactic_list = []




class LSTMHyperModel(HyperModel):
    def __init__(self, n_symbols, embedding_weights):
        self.n_symbols = n_symbols
        self.embedding_weights = embedding_weights

    def build(self, hp):   
        model = Sequential() 
        model.add(Embedding(output_dim=vocab_dim,
                        input_dim=self.n_symbols,
                        mask_zero=True,
                        weights=[self.embedding_weights],
                        input_length=input_length))  
        #model.add(LSTM(units=128,activation='sigmoid'))
        hp_units = hp.Int('units', min_value = 32, max_value = 256, step = 32)
        hp_dropoutrate = hp.Float('dropout', min_value = 0.1, max_value = 0.5, step = 0.1)
        hp_lstmactivation = hp.Choice('lstm_activation', values=['relu', 'tanh', 'sigmoid', 'softmax'], default = 'sigmoid')
        model.add(LSTM(units=hp_units,activation=hp_lstmactivation))
        model.add(Dropout(hp_dropoutrate))
        model.add(Dense(1, activation='sigmoid')) #Output layer


        
        model.compile(loss='binary_crossentropy',
                      optimizer='adam',metrics=['accuracy'])
        return model





def read_syn_nodes():
    f = open("input/syntactic_nodes.txt","r")
    lines = []
    for line in f.readlines():
        line=line.strip('\n')
        lines.append(line)
    f.close()
    return lines



def loadfile():
    neg_full=pd.read_csv('input/'+ sys.argv[2] + '_neg_' + sys.argv[1] + '.csv', usecols=[1, 2], engine='python')
    neg=neg_full['Nodes'].values.tolist()
    neg_full=neg_full.values.tolist()

    #pos=pd.read_csv('input/syn_pos_' + sys.argv[2] + '.csv', usecols=[2], engine='python').values.tolist()
    pos_full=pd.read_csv('input/'+ sys.argv[2] + '_pos_' + sys.argv[1] + '.csv', usecols=[1, 2], engine='python')
    pos=pos_full['Nodes'].values.tolist()
    pos_full=pos_full.values.tolist()
    combined = pos + neg
    combined_full = pos_full + neg_full

    y = np.concatenate((np.ones(len(pos),dtype=int), np.zeros(len(neg),dtype=int))) # ground truth for validation
    x_train, x_test, y_train, y_test = train_test_split(combined_full, y, test_size=0.2, train_size=0.8, random_state=seed_value, stratify=y)
    #get the validation set for tunning if needed
    x_train, x_val, y_train, y_val = train_test_split(x_train, y_train, test_size=0.25, train_size=0.75, random_state=seed_value, stratify=y_train)
    test_block_list = []
    train_block_list = []
    for x in x_test:
        test_list.append(x[0])
        test_block_list.append(x[1])
    x_test = test_block_list
    for x in x_train:
        train_block_list.append(x[1])
    #x_train = np.array(train_block_list)
    x_train = train_block_list

    #code below is for upsampling the data
    x_train_df = pd.DataFrame(data=x_train)
    y_train_df = pd.DataFrame(data=y_train, columns=['y_train'])

    x = pd.concat([x_train_df, y_train_df], axis=1)
    logged = x.loc[x['y_train'] == 1]
    un_logged = x.loc[x['y_train'] == 0]
    logged_upsampled = resample(logged, replace=True, n_samples=len(un_logged), random_state=2020) #upsampling
    logged_upsampled=logged_upsampled.drop(columns=['y_train']).to_numpy()
    un_logged=un_logged.drop(columns=['y_train']).to_numpy()
  
    x_train = np.concatenate((logged_upsampled, un_logged))
    y_train = np.concatenate((np.ones(len(logged_upsampled),dtype=int), np.zeros(len(un_logged),dtype=int))) 



    return combined,y, x_train, x_val, x_test, y_train, y_val,  y_test



def word_splitter(word, docText):
	splitted = re.sub('([A-Z][a-z]+)', r' \1', re.sub('([A-Z]+)', r' \1', word)).split()
	for word in splitted:
		docText.append(word.lower())



def tokenizer(text):
    ''' Simple Parser converting each document to lower-case, then
        removing the breaks for new lines and finally splitting on the
        whitespace
    '''
    #text = [[word for word in str(doc).replace("['", "").replace("']", "").split(' ')] for doc in text]
    newText = []
    for doc in text:
        docText = []
        #for word in str(doc).replace("['", "").replace("']", "").replace(",", "").replace("'", "").split(' '):
        for word in str(doc).replace("'", "").replace("[", "").replace("]", "").replace(",", "").replace('"', "").split(' '):
            if sys.argv[2] == 'sem' or sys.argv[2] == 'comb':
            	if word not in syntactic_nodes:
            		word_splitter(word, docText)
            	else:
            		docText.append(word)
            else:
            	docText.append(word)
            
            
        #print (docText)
        newText.append(docText)
    #print (newText)
    return newText
    


def input_transform(words):
    model=Word2Vec.load('embedding_'+ sys.argv[2] + '/Word2vec_model_' + sys.argv[1] + '.pkl')
    _, _,dictionaries=create_dictionaries(model,words)
    return dictionaries






def create_dictionaries(model=None,
                        combined=None):
    ''' Function does are number of Jobs:
        1- Creates a word to index mapping
        2- Creates a word to vector mapping
        3- Transforms the Training and Testing Dictionaries

    '''
    from keras.preprocessing import sequence
    
    if (combined is not None) and (model is not None):
        gensim_dict = Dictionary()
        gensim_dict.doc2bow(model.wv.vocab.keys(),
                            allow_update=True)
        w2indx = {v: k+1 for k, v in gensim_dict.items()}
        w2vec = {word: model.wv[word] for word in w2indx.keys()}

        def parse_dataset(combined):
            ''' Words become integers
            '''
            data=[]
            for sentence in combined:
                new_txt = []
                for word in sentence:
                    try:
                        new_txt.append(w2indx[word])
                    except:
                        new_txt.append(0)
                data.append(new_txt)
            return data
        combined=parse_dataset(combined)
        combined= sequence.pad_sequences(combined, maxlen=maxlen)
        #print (w2indx)
        return w2indx, w2vec,combined




def word2vec_train(combined):

    model = Word2Vec(size=vocab_dim, #dimension of word embedding vectors
                     min_count=n_exposures,
                     window=window_size,
                     workers=cpu_count, sg=1,
                     iter=n_iterations)
    model.build_vocab(combined)
    model.save('embedding_'+ sys.argv[2] + '/Word2vec_model_' + sys.argv[1] + '.pkl')
    index_dict, word_vectors,combined = create_dictionaries(model=model,combined=combined)
    return   index_dict, word_vectors,combined


def get_data(index_dict,word_vectors,combined):

    n_symbols = len(index_dict) + 1  
    embedding_weights = np.zeros((n_symbols, vocab_dim))
    for word, index in index_dict.items():
        embedding_weights[index, :] = word_vectors[word]


    return n_symbols,embedding_weights








def train_lstm(n_symbols,embedding_weights,x_train,y_train,x_test,y_test, x_val, y_val):
    
    #tf.set_random_seed(seed_value)

    


    model = Sequential()  # or Graph or whatever
    model.add(Embedding(output_dim=vocab_dim,
                        input_dim=n_symbols,
                        mask_zero=True,
                        weights=[embedding_weights],
                        input_length=input_length))  # Adding Input Length
    #model.add(LSTM(units=128, activation='sigmoid', return_sequences=True,input_shape=(vocab_dim,)))
    #model.add(Dropout(0.2))
    model.add(LSTM(units=128,activation='sigmoid'))
    
    #model.add(LSTM(output_dim=100, activation=LeakyReLU(alpha=0.3), input_shape=(vocab_dim,)))
    #model.add(Bidirectional(LSTM(output_dim=100, activation='sigmoid', return_sequences=True, input_shape=(vocab_dim,))))
    #model.add(Bidirectional(LSTM(64, activation='relu')))
    #model.add(Bidirectional(LSTM(output_dim=100, activation='relu', input_shape=(vocab_dim,))))
    model.add(Dropout(0.2))
    #model.add(Bidirectional(LSTM(output_dim=100, activation='relu', input_shape=(vocab_dim,))))
    #model.add(Dropout(0.2))
    #model.add(Dense(64, activation='relu'))
    #model.add(Dropout(0.5))
    #model.add(Dense(64, activation='relu'))
    #model.add(Dropout(0.2))
    model.add(Dense(1, activation='sigmoid')) #Output layer


    print ('Compiling the Model..')
    model.compile(loss='binary_crossentropy',
                  optimizer='adam',metrics=['accuracy'])

    print ("Train...")
    metrics = Metrics.Metrics()
    #history = model.fit(x_train, y_train, batch_size=batch_size, nb_epoch=n_epoch,verbose=1, validation_data=(x_test, y_test), callbacks=[metrics])
    history = model.fit(x_train, y_train, batch_size=batch_size, epochs=n_epoch,verbose=1, validation_data=(x_val, y_val))

    base_min = optimal_epoch(history)
    #eval_metric(model, history, 'loss')
    print ("Evaluate...")
    score = model.evaluate(x_test, y_test,
                                batch_size=batch_size)

    yaml_string = model.to_yaml()
    with open('model_' + sys.argv[2] +'/lstm_'+ sys.argv[1] +'.yml', 'w') as outfile:
        outfile.write( yaml.dump(yaml_string, default_flow_style=True) )
    model.save_weights('model_' + sys.argv[2] +'/lstm_' + sys.argv[1] + '.h5')
    np.set_printoptions(threshold=sys.maxsize)
    #print (model.predict_classes(x_test, verbose=1))
    print ('Test score:', score, model.metrics_names)
    #print ('Precision (training): ', np.mean(metrics.val_precisions), "Recall (training): ", np.mean(metrics.val_recalls))
    #print ('AUC (training): ', np.mean(metrics.val_auc))
	
	
	
    label_predicted = model.predict_classes(x_test, batch_size=batch_size, verbose=1)
    #label_predicted = np.argmax(label_predicted, axis=1)
    pos_label=1
    val_accuracy = accuracy_score(y_test, label_predicted)
    val_recall = recall_score(y_test, label_predicted, labels=[pos_label],pos_label=1, average ='binary')
    val_precision = precision_score(y_test, label_predicted, labels=[pos_label],pos_label=1, average ='binary')
    val_auc = roc_auc_score(y_test, label_predicted)
    val_baccuracy = balanced_accuracy_score(y_test, label_predicted)
    val_f1 = f1_score(y_test, label_predicted, labels=[pos_label], pos_label=1, average='binary')
    print ('Accuracy: ', val_accuracy)
    print ('Balanced Accuracy: ', val_baccuracy)
    print ('AUC (testing): ', val_auc)
    print ('Recall (testing): ', val_recall)
    print ('Precision (testing): ', val_precision)
    print ('F1: ', val_f1)

    
    with open('model_' + sys.argv[2] +'/labels/lstm_predicted_labels_' + sys.argv[1] + '.txt', 'wt') as f:
        for data in label_predicted:
            f.write(str(data).replace("[", "").replace("]", "") + '\n')
    with open('model_' + sys.argv[2] +'/labels/lstm_target_labels_' + sys.argv[1] + '.txt', 'wt') as f:
        for data in y_test:
            f.write(str(data) + '\n')
    with open('model_' + sys.argv[2] +'/labels/lstm_results_' + sys.argv[1] + '.txt', 'wt') as f:
        f.write('Test score:' + str(score) + '  ' + str(model.metrics_names) +'\n')
        #f.write('Precision (training): '+  str(np.mean(metrics.val_precisions)) + '\n' + "Recall (training): " + str(np.mean(metrics.val_recalls)) + '\n')
        f.write('min validation loss achieved in: ' + str(base_min))
        f.write('Accuracy: '+ str(val_accuracy)+ '\n')
        f.write('Balanced Accuracy: '+ str(val_baccuracy)+ '\n')
        f.write('AUC: ' + str(val_auc)+ '\n')
        f.write('Recall: ' + str(val_recall)+ '\n')
        f.write('Precision: ' + str(val_precision) + '\n')
        f.write('F1: ' + str(val_f1) + '\n')

    print ('Getting list of FPs and FNs')
    get_FP_FN(label_predicted, y_test)
        


def pipeline(model,x_train,y_train,x_test,y_test, x_val, y_val):


    print ("Train...")
    metrics = Metrics.Metrics()
    #history = model.fit(x_train, y_train, batch_size=batch_size, nb_epoch=n_epoch,verbose=1, validation_data=(x_test, y_test), callbacks=[metrics])
    history = model.fit(x_train, y_train, batch_size=batch_size, epochs=n_epoch,verbose=1, validation_data=(x_val, y_val))

    base_min = optimal_epoch(history)
    #eval_metric(model, history, 'loss')
    print ("Evaluate...")
    score = model.evaluate(x_test, y_test,
                                batch_size=batch_size)

    yaml_string = model.to_yaml()
    with open('model_' + sys.argv[2] +'/lstm_'+ sys.argv[1] +'.yml', 'w') as outfile:
        outfile.write( yaml.dump(yaml_string, default_flow_style=True) )
    model.save_weights('model_' + sys.argv[2] +'/lstm_' + sys.argv[1] + '.h5')
    np.set_printoptions(threshold=sys.maxsize)
    #print (model.predict_classes(x_test, verbose=1))
    print ('Test score:', score, model.metrics_names)
    #print ('Precision (training): ', np.mean(metrics.val_precisions), "Recall (training): ", np.mean(metrics.val_recalls))
    #print ('AUC (training): ', np.mean(metrics.val_auc))
    
    
    
    label_predicted = model.predict_classes(x_test, batch_size=batch_size, verbose=1)
    #label_predicted = np.argmax(label_predicted, axis=1)
    pos_label=1
    val_accuracy = accuracy_score(y_test, label_predicted)
    val_recall = recall_score(y_test, label_predicted, labels=[pos_label],pos_label=1, average ='binary')
    val_precision = precision_score(y_test, label_predicted, labels=[pos_label],pos_label=1, average ='binary')
    val_auc = roc_auc_score(y_test, label_predicted)
    val_baccuracy = balanced_accuracy_score(y_test, label_predicted)
    val_f1 = f1_score(y_test, label_predicted, labels=[pos_label], pos_label=1, average='binary')
    print ('Accuracy: ', val_accuracy)
    print ('Balanced Accuracy: ', val_baccuracy)
    print ('AUC (testing): ', val_auc)
    print ('Recall (testing): ', val_recall)
    print ('Precision (testing): ', val_precision)
    print ('F1: ', val_f1)

    
    with open('model_' + sys.argv[2] +'/labels/lstm_predicted_labels_' + sys.argv[1] + '.txt', 'wt') as f:
        for data in label_predicted:
            f.write(str(data).replace("[", "").replace("]", "") + '\n')
    with open('model_' + sys.argv[2] +'/labels/lstm_target_labels_' + sys.argv[1] + '.txt', 'wt') as f:
        for data in y_test:
            f.write(str(data) + '\n')
    with open('model_' + sys.argv[2] +'/labels/lstm_results_' + sys.argv[1] + '.txt', 'wt') as f:
        f.write('Test score:' + str(score) + '  ' + str(model.metrics_names) +'\n')
        #f.write('Precision (training): '+  str(np.mean(metrics.val_precisions)) + '\n' + "Recall (training): " + str(np.mean(metrics.val_recalls)) + '\n')
        f.write('min validation loss achieved in: ' + str(base_min))
        f.write('Accuracy: '+ str(val_accuracy)+ '\n')
        f.write('Balanced Accuracy: '+ str(val_baccuracy)+ '\n')
        f.write('AUC: ' + str(val_auc)+ '\n')
        f.write('Recall: ' + str(val_recall)+ '\n')
        f.write('Precision: ' + str(val_precision) + '\n')
        f.write('F1: ' + str(val_f1) + '\n')

    print ('Getting list of FPs and FNs')
    get_FP_FN(label_predicted, y_test)


def get_FP_FN(label_predicted, label_target):
    FP_id_list = []
    FN_id_list = []
    for i in range(0, len(label_predicted)):
        if int(label_predicted[i]) == 1 and int(label_target[i]) == 0:
            FP_id_list.append(i)
        elif int(label_predicted[i]) == 0 and int(label_target[i]) == 1:
            FN_id_list.append(i)
    #print (FP_id_list)
    #print (FN_id_list)
    with open('model_' + sys.argv[2] +'/labels/list/lstm_FP_' + sys.argv[1] + '.txt', 'wt') as f:
        for fp in FP_id_list:
            f.write(str(test_list[int(fp)])+ '\n')
    with open('model_' + sys.argv[2] +'/labels/list/lstm_FN_' + sys.argv[1] + '.txt', 'wt') as f:
        for fn in FN_id_list:
            f.write(str(test_list[int(fn)])+ '\n')
        



def train():
    #for K-fold splitting data, the folds are stratified, meaning that the algorithm attempts to balance the number of instances of each class in each fold.
    #kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)
    print ('Loading Data...')
    combined,y,x_train, x_val, x_test, y_train, y_val,  y_test=loadfile()
    #print (len(combined),len(y))
    print ('Tokenizing...')
    combined = tokenizer(combined)
    x_train = tokenizer (x_train)
    x_test = tokenizer (x_test)
    x_val = tokenizer (x_val)
    print ('Training a Word2vec model...')
    index_dict, word_vectors,combined=word2vec_train(combined)
    x_train = input_transform(x_train)
    x_test = input_transform(x_test)
    x_val = input_transform(x_val)
    print ('Setting up Arrays for Keras Embedding Layer...')
    n_symbols,embedding_weights=get_data(index_dict, word_vectors,combined)
    #print (x_train.shape,y_train.shape)
    hypermodel = LSTMHyperModel(n_symbols,embedding_weights)
    #print(hypermodel.n_symbols)
    #print(hypermodel.embedding_weights)

    tuner = kt.Hyperband(hypermodel,
                     objective = 'val_accuracy', 
                     max_epochs = 10,
                     factor = 3,
                     directory = 'keras_tuner',
                     project_name = sys.argv[1])
    #tuner.search(x_train, y_train, epochs = 10, validation_data = (x_val, y_val))
    #models = tuner.get_best_models(num_models=1)
    train_lstm(n_symbols,embedding_weights,x_train,y_train, x_val , y_val , x_test,y_test)
    #pipeline(models[0],x_train,y_train, x_val , y_val , x_test,y_test)


def eval_metric(model, history, metric_name):
    '''
    Function to evaluate a trained model on a chosen metric. 
    Training and validation metric are plotted in a
    line chart for each epoch.
    
    Parameters:
        history : model training history
        metric_name : loss or accuracy
    Output:
        line chart with epochs of x-axis and metric on
        y-axis
    '''
    metric = history.history[metric_name]
    val_metric = history.history['val_' + metric_name]
    e = range(1, n_epoch + 1)
    plt.plot(e, metric, 'bo', label='Train ' + metric_name)
    plt.plot(e, val_metric, 'b', label='Validation ' + metric_name)
    plt.xlabel('Epoch number')
    plt.ylabel(metric_name)
    plt.title('Comparing training and validation ' + metric_name + ' for ' + model.name)
    plt.legend()
    plt.show()


def optimal_epoch(model_hist):
    '''
    Function to return the epoch number where the validation loss is
    at its minimum
    
    Parameters:
        model_hist : training history of model
    Output:
        epoch number with minimum validation loss
    '''
    min_epoch = np.argmin(model_hist.history['val_loss']) + 1
    print("Minimum validation loss reached in epoch {}".format(min_epoch))
    return min_epoch



def get_available_devices():
    local_device_protos = device_lib.list_local_devices()
    return [x.name for x in local_device_protos]


if __name__=='__main__':
    #tf.debugging.set_log_device_placement(True)
    print(get_available_devices())
    syntactic_nodes = read_syn_nodes()
    train()
    #evaluation()
    print (sys.argv[1])





